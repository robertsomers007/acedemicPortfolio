<?php
  // create short variable name
  $document_root = $_SERVER['DOCUMENT_ROOT'];
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Pay Information</title>
	<style>
		th,td,table {
			border:1px solid black;
			padding:3px
		}
	</style>
  </head>
  <body>
    <h1>Pay Information</h1>
    <h2>Employee Payroll</h2> 
    <?php
      //@$fp = fopen("$document_root/../orders/orders.txt", 'rb');
	  @$fp = fopen("payroll.txt", 'rb');
      flock($fp, LOCK_SH); // lock file for reading

      if (!$fp) {
        echo "<p><strong>No pay recorded.<br />
              Please try again later.</strong></p>";
        exit;
      }
	?>
	<table>
		<tr>
			<th>Employee ID</th>
			<th>Hours Worked</th>
			<th>Hourly Pay Rate</th>
			<th>Gross Pay</th>
			<th>Date</th>
		</tr>
	<?php
      do  {
         $payInstance = fgets($fp);
		 $payDataArray = explode('	', $payInstance);
		 if ($payDataArray[0] != '') {
			 ?>
				<tr>
					<td><?php echo $payDataArray[1] ?></td>
					<td><?php echo $payDataArray[2]?></td>
					<td><?php echo '$' . number_format(intval($payDataArray[3]), 2)?></td>
					<td><?php echo '$' . number_format(intval($payDataArray[4]), 2)?></td>
					<td><?php echo $payDataArray[0]?></td>
				</tr>
			 <?php
		 }
      } while (!feof($fp));

      flock($fp, LOCK_UN); // release read lock --------------------------------------
      fclose($fp); 
    ?>
  </body>
</html>
<?php
	/*
		Robert Somers
		CTP 130 840
		Lab2
	*/
	$employeeID = $_POST['employeeid'];
	$hoursWorked = $_POST['hoursworked'];
	$hourlyWage = $_POST['hourlywage'];
	define("OVERTIME", 1.5);
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Paycheck Results</title>
  </head>
  <body>
    <h1>Paycheck Results</h1> 
    <?php
		$errors = 0;
		if ($employeeID == ""){
			
			echo "Please enter your employee ID<br />";
			$errors++;
		}  if (!(is_numeric($hoursWorked)) || $hoursWorked == ""){
			$hoursWorked = "";
			echo "Please enter a numeric value for Hours Worked<br />";
			$errors++;
		}  if (!(is_numeric($hourlyWage)) || $hourlyWage == "" || $hourlyWage <= 0){
			$hourlyWage = "";
			$errors++;
			echo "Please enter a numeric value above 0 for Hourly wage<br />";
		}	if ($errors > 0){
			echo "<h3>Please re-enter form data below</h3>";
	?>
		<form action="paycheck.php" method="post">
		<table style="border: 0px;">
		<tr>
		  <td>Employee ID</td>
		  <td><input type="text" name="employeeid" size="6" maxlength="6" value="<?php echo $employeeID;?>" /></td>
		</tr>
		<tr>
		  <td>Hours Worked</td>
		  <td><input type="text" name="hoursworked" size="6" maxlength="6" value ="<?php echo $hoursWorked;?>"/></td>
		</tr>
		<tr>
		 <td>Hourly Wage</td>
		 <td><input type="text" name="hourlywage" size="6" maxlength="6" value="<?php echo $hourlyWage;?>"/></td>
		</tr>
		<tr>
		 <td colspan="2" style="text-align: center;"><input type="submit" value="Submit" /></td>
		</tr>
		</table>
		</form>
	<?php 
		} else {
			$amountEarned = 0;
			$dateProcessed = date("m\/d\/Y");
			if ($hoursWorked > 40){
				$amountEarned = number_format(($hourlyWage * 40) + (($hoursWorked - 40) * ($hourlyWage * OVERTIME)), 2);
			} else if ($hoursWorked <=  40){
				$amountEarned = number_format($hourlyWage * $hoursWorked, 2);
			}
			
			echo 
			"Date: " . $dateProcessed . "<br />" .
			"Employee ID: " . $employeeID . "<br />" .
			"Hours Worked: " . $hoursWorked . "<br />" .
			"Hourly Pay Rate: $" . $hourlyWage . "<br />" .
			"Gross Pay: $" . $amountEarned . "<br />";
			
			$dataElement = $dateProcessed . "\t" .
							$employeeID . "\t" .
							$hoursWorked . "\t" .
							$hourlyWage . "\t" .
							$amountEarned . "\n";
		
			@$fp = fopen("payroll.txt", 'ab');  //'a' appends data to the end of the file if it exists --------------------------------------
	   
			if (!$fp) {
				echo "<p><strong> Your pay could not be processed at this time.
				Please try again later.</strong></p>";
				exit;
			}
			flock($fp, LOCK_EX);
			fwrite($fp, $dataElement, strlen($dataElement));
			flock($fp, LOCK_UN);
			fclose($fp);
			echo "Your pay has been processed.<br />";
			
		}
		echo "<a href=\"viewpay.php\">View Pay Info</a>"
	?>
	
	
  </body>
</html>

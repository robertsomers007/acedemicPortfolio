<!DOCTYPE html>
<html>
<!--
	Robert Somers
	CTP 130 840
	Lab 6
-->
  <head>
   <title>Two Trains</title>
  </head>
  <body>
	<h1>Two Trains</h1>
	<?php
		$trainASpd = $_POST['traina'];
		$trainBSpd = $_POST['trainb'];
		$distance = $_POST['distance'];
		$errors = 0;
		function validateInputs(&$data, $fieldName){
			$validateErrors = 0;
			if ($data == ""){
				echo "<p>\"" . $fieldName . "\" is a required field</p>";
				$data == "";
				$validateErrors++;
			} else if (is_numeric($data) == false || $data <= 0){
				echo "<p>\"" . $fieldName . "\" must be a number greater than 0</p>";
				$data == "";
				$validateErrors++;
			}
			if ($validateErrors == 0){
				return $data;
			}
			
		}
		function displayForm($trainA, $trainB, $dist){
			?>
			<p>*Please re-enter form information below:</p>
			<form action="lab6Trains.php" method="post">
				<table style="border: 0px;">
					<tr>
						<td>Speed of Train A</td>
						<td><input type="text" name="traina" size="10" maxlength="10" value="<?php echo $trainA; ?>"/></td>
						<td>mph</td>
					</tr>
					<tr>
						<td>Speed of Train B</td>
						<td><input type="text" name="trainb" size="10" maxlength="10" value="<?php echo $trainB; ?>"/></td>
						<td>mph</td>
					</tr>
					<tr>
						<td>Distance</td>
						<td><input type="text" name="distance" size="10" maxlength="10" value="<?php echo $dist; ?>"/></td>
						<td>miles</td>
					</tr>
					<tr>
						<td colspan="2" style="text-align: center;"><input type="submit" value="Submit" /></td>
					</tr>
				</table>
			</form>
			<?php
		}
		$speedA = validateInputs($trainASpd, "Speed of Train A");
		$speedB = validateInputs($trainBSpd, "Speed of Train B");
		$goodDist = validateInputs($distance, "Distance Between Trains");
		if ($speedA == "" || $speedB == "" || $goodDist == ""){
			displayForm($speedA, $speedB, $goodDist);
		} else {
			$distanceA = number_format((($speedA / $speedB) * $goodDist) / (1 + ($speedA/$speedB)), 2);
			$distanceB = number_format($goodDist - $distanceA, 2);
			$timeA = number_format(($distanceA / $speedA), 2);
			$timeB = number_format(($distanceB / $speedB), 2);
			
			echo "<p>Train A  traveled " . $distanceA . " miles in " . $timeA . " hours at " . $speedA . "mph</p>";
			echo "<p>Train B  traveled " . $distanceB . " miles in " . $timeB . " hours at " . $speedB . "mph</p>";
			echo "<p>The sum of the two distances is " . ($distanceA + $distanceB) . " miles</p>";
		}	
	?>
  </body>
</html>
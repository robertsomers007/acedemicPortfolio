<!DOCTYPE html>
<html>
<!--
	Robert Somers
	CTP 130 840
	Lab 6
-->
  <head>
   <title>Word Shuffle</title>
  </head>
  <body>
	<h1>Word Shuffle</h1>
	<?php
			$word1 = $_POST['word1'];
			$word2 = $_POST['word2'];
			$word3 = $_POST['word3'];
			$word4 = $_POST['word4'];
			$errorCount = 0;
			function displayErrors($fieldName, $errorMsg){
				echo "<p>Error for \"" . $fieldName . "\": " . $errorMsg . "</p>";
			}
			function validateWord($data, $fieldName){
				global $errorCount;
				if ($data == ""){
					$errorCount++;
					displayErrors($fieldName, "This field is required");
				} else {
					if (!(ctype_alpha($data))) {
						$errorCount++;
						displayErrors($fieldName, "Only letters may be entered.");
					}else if (strlen($data) > 7 || strlen($data) < 4) {
						$errorCount++;
						displayErrors($fieldName, "Words must be between 4 and 7 characters long.");
					}
					if ($errorCount == 0){
						$returnData = str_shuffle($data);
						$returnData = strtoupper($returnData);
						return $returnData;
					}
				}
			}
			$shuffledWord1 = validateWord($word1, "Word 1");
			$shuffledWord2 = validateWord($word2, "Word 2");
			$shuffledWord3 = validateWord($word3, "Word 3");
			$shuffledWord4 = validateWord($word4, "Word 4");
			if ($errorCount != 0){
				echo "<p>Please use the \"Back\" to re-enter data.</p>";
			} else {
				echo "<p>Word 1: " . $shuffledWord1 . "</p>";
				echo "<p>Word 2: " . $shuffledWord2 . "</p>";
				echo "<p>Word 3: " . $shuffledWord3 . "</p>";
				echo "<p>Word 4: " . $shuffledWord4 . "</p>";
			}
			
	?>
  </body>
</html>
<!DOCTYPE html>
<html>
<!--
	Robert Somers
	CTP 130 840
	Lab4
-->
  <head>
   <title>Associative Array</title>
  </head>
  
  <body>
	<h1>Associative Array</h1>
    <?php
		$boxes = array(
			array("Small Box",12,10,2.5),
			array("Medium Box",30,20,4),
			array("Large Box",60,40,11.5)
		);
		for ($i=0;$i<count($boxes);++$i){
			$volume = $boxes[$i][1] * $boxes[$i][2] * $boxes[$i][3];
			echo $boxes[$i][0] . " = " . $boxes[$i][1]. "\"L x " . $boxes[$i][2] . "\"W x " . $boxes[$i][3] . "\"D" . " = " . $volume . "cu. in.<br />";
		}
	?>
	
  </body>
</html>
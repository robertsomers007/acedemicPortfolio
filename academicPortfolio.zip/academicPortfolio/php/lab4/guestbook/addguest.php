<!DOCTYPE html>
<html>
<!--
	Robert Somers
	CTP 130 840
	Lab4
-->
  <head>
   <title>Guest Book</title>
   <style>
		.information {
			border:1px solid black;
			padding:5px;
		}
	</style>
  </head>
  
  <body>
	<h1>Guest Book</h1>
	<?php
	if(isset($_GET['action'])) {
			if ((file_exists("guests.txt")) && (filesize("guests.txt") !=0)) {
				$guestArray = file("guests.txt");
				switch ($_GET['action']) {
					case 'Sort Names':
						sort($guestArray);
						break; 
					case 'Delete Duplicates':
						$guestArray = array_unique($guestArray);
						$guestArray = array_values($guestArray);
						break; 
				}
				if (count($guestArray)>0) {
					$newGuest = implode($guestArray);
					$guestStore = fopen("guests.txt", "wb");
					if ($guestStore === false)
						echo "There was an error updating the guest file\n";
					else {
						fwrite($guestStore, $newGuest);
						fclose($guestStore);
					} //end else 
				} //end if count()
				else
					unlink("guests.txt");
			}//end inner if
		}
		?>
	<?php
		if ((!file_exists("guests.txt"))|| (filesize("guests.txt")== 0))
			echo "<p>There are no guests yet.</p>\n";
		else {
			$guestArray = file("guests.txt");
			echo "<table style=\"background-color:lightgray\" border=\"1\" width=\"50%\">\n<tr><th>Name:</th><th>E-mail</th></tr>";
			$count= count($guestArray);
			foreach ($guestArray as $guest){
				$currGuest = explode("	", $guest);
				echo "<tr><td>" . htmlentities($currGuest[0]) . "</td><td>" . htmlentities($currGuest[1]) . "</td></tr>";
			}
			echo "</table>\n";
		}
?>

	
	<a href="addguest.php?action=Sort%20Names">Sort Names</a><br/>
	<a href="addguest.php?action=Delete%20Duplicates">Remove duplicates</a><br/>
	
	<?php
		if (isset($_POST['submit'])){
			$guestName = $_POST['guestname'];
			$guestEmail = $_POST['guestemail'];
			if (empty($guestName)) {
				echo "Please enter your name<br />";
			}
			if (empty($guestEmail)){
				echo "Please enter your email<br />";
			} else if (!(filter_var($guestEmail, FILTER_VALIDATE_EMAIL))){
				echo "This email is invalid, please re-enter your email below.";
			} else {
				$guestRecord = "$guestName\t$guestEmail\n";
				$guestFile = fopen("guests.txt", "ab");
				if($guestFile === FALSE)
					echo "There was an error saving your information!\n";
				else {
					fwrite($guestFile, $guestRecord);
					fclose($guestFile);
					echo "Your information has been saved. <strong><a href=\"addguest.php\">Click here to see updated list.</strong></a>\n"; 
					$Subject = "";
					$Message = "";
				}
			}
		}
	?>
	
	<p><strong>Sign the guest book</strong></p>
    <form action="addguest.php" method="POST">
    <table style="border: 0px;">
    <tr>
      <td>Name:</td>
      <td><input type="text" name="guestname" size="30" maxlength="40" /></td>
    </tr>
    <tr>
     <td>Email Address:</td>
     <td><input type="text" name="guestemail" size="30" maxlength="40" /></td>
    </tr>
    <tr>
     <td colspan="2" style="text-align: center;"><input type="reset" name="reset" value="Clear Form" /></td>
     <td colspan="2" style="text-align: center;"><input type="submit" name="submit" value="Sign the Guest Book" /></td>
    </tr>
    </table>
    </form>
  </body>
</html>